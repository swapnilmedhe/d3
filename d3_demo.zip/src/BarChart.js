
import React, { Component } from 'react'
import * as d3 from "d3";

export class BarChart extends Component {
    componentDidMount() {
        this.drawChart();
      }


      drawChart() {
  
        const data = [20, 15, 25, 6, 9, 10]; // demo data
       
        const svg = d3.select("body").append("svg").attr("width", 700).attr("height", 300);
        svg.selectAll("rect") // for rectangle shape 
        .data(data)  // data is in wating state
        .enter()
        .append("rect")
        .attr("x", ( d, i) => i * 50)  // to shift along x axis multiply (by const 50) btn two graph
        .attr("y", (d, i) => 300 - 10 * d)    
        .attr("width", 25)  // constant width of the graph
        .attr("height",  (d, i) => d * 10)  // for setting height  of bar 
        .attr("fill", "green");  // for color 


        // appling text  on the graph 
        svg.selectAll("text")
        .data(data)
        .enter()
        .append("text")
        .text((d) => d)
        .attr("x", (d, i) => i * 50)  // to shift along x axis multiply by const 50
        .attr("y", (d, i) => 300- 10 * d)

      }



    render() {
        return (
            <div>
               <h2>Bar chart example !!</h2>
            {/* <div id={"#" + this.props.id}></div> */}
            </div>
        )
    }
}

export default BarChart


