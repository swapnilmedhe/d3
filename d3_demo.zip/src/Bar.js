import React, { Component } from 'react'

export class Bar extends Component {
    constructor(props) {
        super(props)
      }
      
    
    render() {
        let style = {
            fill: "green"
          }

          return(
            <g>
                <rect class="bar" style={style} x={this.props.x} y={this.props.y + 5} width={this.props.width} height={this.props.height} />
            </g>
          )
        }
    }


export default Bar
