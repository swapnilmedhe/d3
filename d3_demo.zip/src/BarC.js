import React, { Component } from 'react';
import * as d3 from "d3";
import XAxis from './XAxis';
import YAxis from './YAxis';
import Bar from './Bar';

export class BarC extends Component {

    render() {
        
    let style = {
        fill: "steelblue"
      }


    let data = this.props.data;
    let bars = [];
    let bottom = 450


    let margin = {top: 20, right: 20, bottom: 30, left: 35},
      width = this.props.width - margin.left - margin.right,
      height = this.props.height - margin.top - margin.bottom;

    let letters = data.map((d) => d.letter)  /// itrating 
     

    // finding range    
    let ticks = d3.range(0, width, (width / data.length)) 
    console.log(width,height,(width / data.length),ticks)



    // x 
    let x = d3.scaleOrdinal()
      .domain(letters)
      .range(ticks)
      console.log("x->",x)


       //y
      let y = d3.scaleLinear()
        .domain([0, d3.max(data, (d) => d.frequency)])
        .range([height, 0])


    data.forEach((data, index) => {
      bars.push(<Bar key={index} x={x(data.letter)} y={bottom - 6 - (height - y(data.frequency))} width={20} height={height - y(data.frequency)} />)
    })
  


        return (
          <svg width={this.props.width} height={this.props.height}>
                  	        <YAxis y={40} labels={y.ticks().reverse()} start={15} end={height} />

                  <g className="chart" transform={`translate(${margin.left},${margin.top})`}>
                  { bars }
                  <XAxis x={ bottom } labels={letters} start={0} end={width} />
                </g>
          </svg>
        )
    }
}

export default BarC
